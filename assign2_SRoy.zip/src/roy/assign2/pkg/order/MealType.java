/**
 * Enumeration for Meal type
 */
package roy.assign2.pkg.order;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public enum MealType {
		VEGAN,
		LOW_CARB,
		HIGH_CARB;
	
	MealType(){}
		
}
