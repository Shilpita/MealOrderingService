/**
 * Interface of Diet Plan
 */
package roy.assign2.pkg.diet;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public interface DietPlan {
	public String showPlan();
	public double getCostOfPlan(); 
}
