/**
 * Class to create meal of HIGH_CARB category 
 */
package roy.assign2.pkg.mealcategories;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public class HighCarbMeal extends ParentMealCategory {
		public HighCarbMeal(){
			super();
		}
}
