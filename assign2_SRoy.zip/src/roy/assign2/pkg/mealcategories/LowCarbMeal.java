/**
 * Class to create meal of LOW_CARB category 
 */
package roy.assign2.pkg.mealcategories;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public class LowCarbMeal extends ParentMealCategory {
		public LowCarbMeal(){
			super();
		}
}
