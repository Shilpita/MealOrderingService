/**
 * Class to create meal of HITCH HIKER category 
 */
package roy.assign2.pkg.mealcategories;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public class HitchHikerMeal extends ParentMealCategory {
		public HitchHikerMeal(){
			super();
		}
}
