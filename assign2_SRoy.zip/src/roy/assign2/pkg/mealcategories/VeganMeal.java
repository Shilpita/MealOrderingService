/**
 * Class to create meal of VEGAN category 
 */
package roy.assign2.pkg.mealcategories;

/**
 * @author ShilpitaRoy(W1190513)
 *
 */
public class VeganMeal extends ParentMealCategory {
		public VeganMeal(){
			super();
		}
}
